import 'package:flutter/material.dart';
import '../../core/services/auth_service.dart';

class VerifyPendingPage extends StatelessWidget {
  const VerifyPendingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Verifikasi Email"),
        backgroundColor: const Color(0xFFD50000),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.email, size: 80, color: Color(0xFFD50000)),
            const SizedBox(height: 20),
            const Text(
              "Email belum diverifikasi",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              "Silakan cek inbox atau spam untuk verifikasi.\n"
              "Jika belum menerima email, klik tombol di bawah.",
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD50000),
                minimumSize: const Size(double.infinity, 50),
              ),
              onPressed: () async {
                final res = await AuthService().resendVerification();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      res == "sent"
                          ? "Email verifikasi sudah dikirim ulang!"
                          : res,
                    ),
                  ),
                );
              },
              child: const Text("Kirim Ulang Email Verifikasi"),
            ),

            const SizedBox(height: 20),

            TextButton(
              onPressed: () => Navigator.pushReplacementNamed(context, "/login"),
              child: const Text(
                "Kembali ke Login",
                style: TextStyle(color: Color(0xFFD50000)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
