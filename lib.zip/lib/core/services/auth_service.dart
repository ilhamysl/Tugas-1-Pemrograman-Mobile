import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// REGISTER USER BIASA
  Future<String> register(String name, String email, String password) async {
    try {
      if (name.isEmpty || email.isEmpty || password.isEmpty) {
        return "Semua field wajib diisi.";
      }

      UserCredential cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = cred.user;
      if (user == null) return "Gagal membuat akun.";

      // SIMPAN USER
      await _firestore.collection("users").doc(user.uid).set({
        "uid": user.uid,
        "name": name,
        "email": email,
        "role": "user",
        "createdAt": FieldValue.serverTimestamp(),
      });

      // KIRIM VERIFIKASI EMAIL
      await user.sendEmailVerification();
      await _auth.signOut();

      return "success";
    } on FirebaseAuthException catch (e) {
      return _handleFirebaseAuthError(e);
    } catch (e) {
      return "Terjadi kesalahan. Silakan coba lagi.";
    }
  }

  /// LOGIN (ADMIN / USER)
  Future<String> login(String identifier, String password) async {
    try {
      if (identifier.isEmpty || password.isEmpty) {
        return "Email/kode dan password wajib diisi.";
      }

      // === cek admin ===
      final adminSnap = await _firestore
          .collection("admins")
          .where("code", isEqualTo: identifier)
          .limit(1)
          .get();

      if (adminSnap.docs.isNotEmpty) {
        final admin = adminSnap.docs.first.data();
        if (password != admin["password"]) {
          return "Kode admin atau password salah.";
        }

        return "admin_success|${admin["code"]}|${admin["regionName"]}";
      }

      // === user biasa ===
      UserCredential cred = await _auth.signInWithEmailAndPassword(
        email: identifier,
        password: password,
      );

      final user = cred.user;
      if (user == null) return "Akun tidak ditemukan.";

      await user.reload();

      if (!user.emailVerified) {
        await _auth.signOut();
        return "unverified";
      }

      return "user_success";
    } on FirebaseAuthException catch (e) {
      return _handleFirebaseAuthError(e);
    } catch (e) {
      return "Terjadi kesalahan. Silakan coba lagi.";
    }
  }

  /// RESEND EMAIL VERIFICATION
  Future<String> resendVerification() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return "User tidak ditemukan.";

      await user.sendEmailVerification();
      return "sent";
    } catch (e) {
      return "Gagal mengirim ulang email verifikasi.";
    }
  }

  Future<void> logout() async => _auth.signOut();

  String _handleFirebaseAuthError(FirebaseAuthException e) {
    switch (e.code) {
      case "invalid-email":
        return "Format email tidak valid.";
      case "wrong-password":
        return "Email atau password salah.";
      case "user-not-found":
        return "Akun tidak ditemukan.";
      case "email-already-in-use":
        return "Email sudah terdaftar.";
      case "weak-password":
        return "Password terlalu lemah.";
      default:
        return "Error (${e.code}).";
    }
  }
}
